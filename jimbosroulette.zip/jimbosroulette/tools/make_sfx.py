#!/usr/bin/env python3
"""Synthesizes all Jimbo's Roulette sound effects + music as raw PCM16LE mono @ 22050 Hz.
Usage: python3 tools/make_sfx.py   (needs numpy + scipy). Output: romfs/sfx/*.raw"""
import os
import numpy as np
from scipy import signal

SR = 22050
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), "..", "romfs", "sfx")
os.makedirs(OUT, exist_ok=True)

def T(d): return np.arange(int(SR * d)) / SR
def ex(d, tau): return np.exp(-T(d) / tau)
def noise(d): return rng.uniform(-1, 1, int(SR * d))
def lp(x, fc): b, a = signal.butter(2, fc / (SR / 2), "low"); return signal.lfilter(b, a, x)
def hp(x, fc): b, a = signal.butter(2, fc / (SR / 2), "high"); return signal.lfilter(b, a, x)
def bp(x, lo, hi): b, a = signal.butter(2, [lo / (SR / 2), hi / (SR / 2)], "band"); return signal.lfilter(b, a, x)
def sine(f, d): return np.sin(2 * np.pi * f * T(d))
def saw(f, d): return signal.sawtooth(2 * np.pi * f * T(d))
def square(f, d): return np.sign(np.sin(2 * np.pi * f * T(d)))
def sweep(f0, f1, d):
    f = np.linspace(f0, f1, int(SR * d))
    return np.sin(2 * np.pi * np.cumsum(f) / SR)
def mix(n, *parts):
    out = np.zeros(int(SR * n))
    for at, x, g in parts:
        i = int(SR * at); j = min(len(out), i + len(x))
        if i < len(out): out[i:j] += g * x[: j - i]
    return out
def fade(x, ms=4):
    n = int(SR * ms / 1000); x = x.copy()
    x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n); return x
def norm(x, peak=0.9): return x / (np.max(np.abs(x)) + 1e-9) * peak
def save(name, x, peak=0.9):
    pcm = (np.clip(fade(norm(x, peak)), -1, 1) * 32767).astype("<i2")
    pcm.tofile(os.path.join(OUT, name + ".raw"))
    print(f"{name:10s} {len(pcm)/SR:5.2f}s")

# ---- effects ----------------------------------------------------------
d = 0.7
bang = mix(d,
    (0, hp(noise(d), 500) * ex(d, 0.02), 1.0),
    (0, lp(noise(d), 400) * ex(d, 0.18), 1.4),
    (0, sweep(120, 35, d) * ex(d, 0.15), 1.2),
    (0, lp(noise(d), 1800) * ex(d, 0.25), 0.35))
save("bang", np.tanh(bang * 1.5))

d = 0.22
click = mix(d,
    (0.000, bp(noise(0.05), 1500, 6000) * ex(0.05, 0.004), 1.0),
    (0.075, bp(noise(0.05), 1200, 5000) * ex(0.05, 0.004), 0.7),
    (0.075, sine(220, 0.08) * ex(0.08, 0.012), 0.6))
save("click", click)

d = 0.75
parts = []
for i in range(5):
    tink = mix(0.15, (0, sine(1700 - 60 * i, 0.15) * ex(0.15, 0.03), 1.0), (0, bp(noise(0.05), 2000, 7000) * ex(0.05, 0.005), 1.0))
    parts.append((0.12 * i, tink, 0.8))
    parts.append((0.12 * i, sine(300, 0.1) * ex(0.1, 0.02), 0.6))
save("load", mix(d, *parts))

d = 0.3
shuf = bp(noise(d), 2000, 7000) * (0.5 + 0.5 * np.sin(2 * np.pi * 32 * T(d))) * np.sin(np.pi * T(d) / d)
save("deal", shuf)

d = 0.5
clunk = lambda f: lp(noise(0.12), 900) * ex(0.12, 0.03) + sine(f, 0.12) * ex(0.12, 0.05)
save("rack", mix(d, (0, clunk(150), 1.0), (0.04, bp(noise(0.14), 2000, 5000) * np.sin(np.pi * T(0.14) / 0.14), 0.25),
                 (0.2, clunk(190), 1.0)))

d = 0.45
ph = 2 * np.pi * np.cumsum(700 + 800 * (T(d) / d) + 20 * np.sin(2 * np.pi * 12 * T(d))) / SR
glass = (np.sin(ph) + 0.4 * np.sin(2 * ph)) * np.sin(np.pi * T(d) / d) ** 0.7
save("glass", glass)

d = 0.5
note = lambda f: (sine(f, 0.35) + 0.3 * sine(2 * f, 0.35)) * ex(0.35, 0.13)
save("heal", mix(d, (0, note(523), 1.0), (0.12, note(784), 1.0)))

d = 0.4
bad = lp(saw(1, d) * 0 + signal.sawtooth(2 * np.pi * np.cumsum(np.linspace(300, 90, int(SR * d))) / SR), 1500)
bad *= (0.7 + 0.3 * np.sin(2 * np.pi * 18 * T(d))) * ex(d, 0.25)
save("bad", bad)

d = 0.45
parts = []
at = 0.0
for i in range(7):
    parts.append((at, bp(noise(0.03), 2000, 7000) * ex(0.03, 0.003) + sine(3000, 0.03) * ex(0.03, 0.004), 0.8))
    at += 0.04 + 0.006 * i
parts.append((0.33, lp(noise(0.1), 1200) * ex(0.1, 0.03) + sine(400, 0.1) * ex(0.1, 0.04), 1.0))
save("cuffs", mix(d, *parts))

d = 0.55
sawfx = (signal.sawtooth(2 * np.pi * 90 * T(d)) * 0.5 + bp(noise(d), 1000, 6000)) * np.abs(np.sin(2 * np.pi * 9 * T(d)))
sawfx *= np.minimum(1, T(d) / 0.05) * np.minimum(1, (d - T(d)) / 0.1)
save("saw", sawfx)

d = 0.35
up = sweep(300, 1200, d / 2); dn = sweep(1200, 300, d / 2)
inv = np.concatenate([up, dn]) * 0.7
inv += 0.3 * np.sign(inv)
inv *= np.sin(np.pi * T(d)[: len(inv)] / d)
save("invert", inv)

d = 0.5
dt = lambda f1, f2, dd: (sine(f1, dd) + sine(f2, dd)) * np.minimum(1, (dd - T(dd)) / 0.01)
save("phone", mix(d, (0.00, dt(697, 1209, 0.06), 0.7), (0.10, dt(770, 1336, 0.06), 0.7),
                  (0.20, dt(852, 1477, 0.06), 0.7), (0.30, sine(880, 0.18) * ex(0.18, 0.1), 0.7)))

d = 0.6
thump = lambda: sweep(90, 40, 0.15) * ex(0.15, 0.05)
rise = (signal.sawtooth(2 * np.pi * np.cumsum(np.linspace(300, 1800, int(SR * 0.3))) / SR)) * np.sin(np.pi * T(0.3) / 0.3)
save("adrenaline", mix(d, (0, thump(), 1.3), (0.16, thump(), 1.0), (0.3, rise, 0.45)))

d = 0.6
zap = hp(noise(d), 800) * (np.sign(np.sin(2 * np.pi * 55 * T(d))) * 0.5 + 0.5) * ex(d, 0.25)
zap += 0.6 * signal.sawtooth(2 * np.pi * np.cumsum(np.linspace(240, 70, int(SR * d))) / SR) * ex(d, 0.3)
save("cable", zap)

save("select", sine(1000, 0.05) * ex(0.05, 0.012), 0.5)
d = 0.14
save("deny", square(140, d) * np.linspace(1, 0.1, int(SR * d)), 0.5)

d = 1.8
gong = mix(d, (0, lp(noise(0.08), 1500) * ex(0.08, 0.02), 0.8))
for f, tau, g in [(110, 1.2, 1.0), (156, 0.9, 0.7), (224, 0.7, 0.5), (331, 0.5, 0.35), (47, 1.4, 0.8)]:
    gong += mix(d, (0, sine(f, d) * ex(d, tau), g))
save("round", gong)

d = 1.5
notes = [(0.0, 392), (0.18, 494), (0.36, 587), (0.54, 784)]
parts = [(a, (sine(f, 0.9) + 0.3 * sine(2 * f, 0.9)) * ex(0.9, 0.3), 1.0) for a, f in notes]
save("win", mix(d, *parts))

d = 1.7
parts = []
for i, f in enumerate([330, 277, 220, 165]):
    n = lp(signal.sawtooth(2 * np.pi * f * T(0.5)), 1100) * ex(0.5, 0.25)
    parts.append((0.3 * i, n, 1.0))
parts.append((1.2, sweep(80, 30, 0.5) * ex(0.5, 0.2), 1.4))
save("lose", mix(d, *parts))

d = 0.07
tri = signal.sawtooth(2 * np.pi * np.cumsum(np.linspace(520, 720, int(SR * d))) / SR, 0.5)
save("blip", tri * ex(d, 0.03) * np.minimum(1, T(d) / 0.004), 0.7)   # Jimbo's voice; pitched randomly at runtime

# ---- music: 16 s seamless loop ---------------------------------------
L = 16
n = SR * L
tt = np.arange(n) / SR
def cyc(k): return np.sin(2 * np.pi * (k / L) * tt)   # integer cycles -> loops cleanly
drone = (cyc(880) + 0.7 * cyc(881) + 0.5 * cyc(1320) + 0.35 * cyc(1046)) * (0.75 + 0.25 * cyc(2))
drone += 0.15 * lp(np.sign(np.sin(2 * np.pi * 55 * tt)), 300) * (0.6 + 0.4 * cyc(1))
music = drone * 0.6
def add_circ(buf, x, at):
    idx = (int(at * SR) + np.arange(len(x))) % len(buf); np.add.at(buf, idx, x)
for beat in range(16):                      # slow heartbeat, 60 bpm
    th = sweep(70, 38, 0.3) * ex(0.3, 0.07)
    add_circ(music, th * 0.9, beat * 1.0); add_circ(music, th * 0.55, beat * 1.0 + 0.22)
for tk in range(32):                        # faint clock tick
    add_circ(music, bp(noise(0.03), 2500, 6000) * ex(0.03, 0.004) * 0.12, tk * 0.5 + 0.25)
for at, f in [(1.5, 220), (4.0, 261.6), (6.5, 196), (9.0, 246.9), (11.5, 220), (13.5, 164.8)]:
    s = (sine(f, 2.5) + 0.3 * sine(2 * f, 2.5)) * ex(2.5, 0.7) * np.minimum(1, T(2.5) / 0.02)
    add_circ(music, s * 0.22, at)
N = int(0.05 * SR); w = np.linspace(0, 1, N)       # crossfade tail into head -> click-free loop
music = music[N:].copy() if False else music
y = music[N:].copy(); y[-N:] = music[-N:] * (1 - w) + music[:N] * w
music = y
pcm = (norm(music, 0.5) * 32767).astype("<i2"); pcm.tofile(os.path.join(OUT, "music.raw"))
print(f"music      {len(pcm)/SR:5.2f}s")
