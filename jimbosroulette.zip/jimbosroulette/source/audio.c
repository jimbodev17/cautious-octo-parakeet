#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "audio.h"
#include "game.h"

#define RATE     22050
#define NCHAN    9      /* channel 0 = music, 1..7 = effects, 8 = Jimbo's voice */
#define NSFXCH   7
#define SFX_VOL  0.9f
#define MUS_VOL  0.45f

typedef struct { s16 *data; u32 nsamples; } Snd;

/* must match the Sfx enum order in game.h */
static const char *FILES[SFX_COUNT] = {
    "bang", "click", "load", "deal", "rack", "glass", "heal", "bad", "cuffs",
    "saw", "invert", "phone", "adrenaline", "cable", "select", "deny",
    "round", "win", "lose", "blip"};

static Snd g_snd[SFX_COUNT];
static Snd g_music;
static ndspWaveBuf g_wb[NCHAN];
static bool g_ok = false;
static bool g_musicOn = true;
static int g_next = 1;

static bool load_raw(const char *name, Snd *s)
{
    char path[64];
    snprintf(path, sizeof path, "romfs:/sfx/%s.raw", name);
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0) { fclose(f); return false; }
    s->data = (s16 *)linearAlloc(sz);          /* DSP needs linear memory */
    if (!s->data) { fclose(f); return false; }
    if (fread(s->data, 1, sz, f) != (size_t)sz) {
        fclose(f);
        linearFree(s->data);
        s->data = NULL;
        return false;
    }
    fclose(f);
    s->nsamples = (u32)(sz / 2);
    DSP_FlushDataCache(s->data, sz);
    return true;
}

static void start(int ch, const Snd *s, float vol, bool loop, float rate)
{
    if (!s->data) return;
    float mix[12];
    memset(mix, 0, sizeof mix);
    mix[0] = mix[1] = vol;
    ndspChnWaveBufClear(ch);
    ndspChnSetRate(ch, rate);
    ndspChnSetMix(ch, mix);
    memset(&g_wb[ch], 0, sizeof g_wb[ch]);
    g_wb[ch].data_vaddr = s->data;
    g_wb[ch].nsamples = s->nsamples;
    g_wb[ch].looping = loop;
    g_wb[ch].status = NDSP_WBUF_FREE;
    ndspChnWaveBufAdd(ch, &g_wb[ch]);
}

void audio_init(void)
{
    if (R_FAILED(ndspInit())) {          /* no dspfirm.cdc on the SD card */
        g_ok = false;
        return;
    }
    g_ok = true;
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    for (int ch = 0; ch < NCHAN; ch++) {
        ndspChnReset(ch);
        ndspChnSetInterp(ch, NDSP_INTERP_LINEAR);
        ndspChnSetRate(ch, RATE);
        ndspChnSetFormat(ch, NDSP_FORMAT_MONO_PCM16);
    }
    for (int i = 0; i < SFX_COUNT; i++) load_raw(FILES[i], &g_snd[i]);
    if (load_raw("music", &g_music)) start(0, &g_music, MUS_VOL, true, RATE);
}

void audio_exit(void)
{
    if (!g_ok) return;
    for (int ch = 0; ch < NCHAN; ch++) ndspChnWaveBufClear(ch);
    for (int i = 0; i < SFX_COUNT; i++) if (g_snd[i].data) linearFree(g_snd[i].data);
    if (g_music.data) linearFree(g_music.data);
    ndspExit();
    g_ok = false;
}

bool audio_ok(void) { return g_ok; }
bool audio_music_on(void) { return g_musicOn; }

void audio_play(int sfx)
{
    if (!g_ok || sfx < 0 || sfx >= SFX_COUNT) return;
    start(g_next, &g_snd[sfx], SFX_VOL, false, RATE);
    g_next = (g_next % NSFXCH) + 1;   /* round-robin over channels 1..7 */
}

void audio_toggle_music(void)
{
    if (!g_ok) return;
    g_musicOn = !g_musicOn;
    if (g_musicOn) start(0, &g_music, MUS_VOL, true, RATE);
    else ndspChnWaveBufClear(0);
}

void audio_blip(float pitch)
{
    if (!g_ok) return;
    start(NCHAN - 1, &g_snd[SFX_BLIP], 0.55f, false, RATE * pitch);
}
