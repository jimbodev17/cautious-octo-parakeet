#include "game.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *NAMES[IT_COUNT] = {
    "", "Magnifying Glass", "Beer", "Cigarettes", "Handcuffs", "Hand Saw",
    "Expired Medicine", "Inverter", "Burner Phone", "Adrenaline"};
static const char *SHORT[IT_COUNT] = {
    "", "GLS", "BER", "CIG", "CUF", "SAW", "MED", "INV", "PHN", "ADR"};
static const char *DESC[IT_COUNT] = {
    "",
    "See if the chamber is live or blank.",
    "Rack the gun: ejects the current shell.",
    "Restore 1 charge.",
    "Opponent skips their next turn.",
    "Next shot deals double damage.",
    "50%: +2 charges. 50%: -1 charge.",
    "Flip the current shell live/blank.",
    "Reveal a shell further down the line.",
    "Steal an item and use it at once."};

const char *item_name(int t)  { return NAMES[t]; }
const char *item_short(int t) { return SHORT[t]; }
const char *item_desc(int t)  { return DESC[t]; }

void game_sfx(Game *g, int sfx)
{
    if (g->nsfx < (int)(sizeof g->sfxq / sizeof g->sfxq[0])) g->sfxq[g->nsfx++] = sfx;
}

void game_event(Game *g, int type, int who, int a, int b, int c, int d)
{
    if (g->nev < (int)(sizeof g->evq / sizeof g->evq[0]))
        g->evq[g->nev++] = (GameEvent){type, who, a, b, c, d};
}

static const char *who_name(int w) { return w == PLAYER ? "You" : "Jimbo"; }
static const char *verb_s(int w)   { return w == PLAYER ? "" : "s"; }

void game_say(Game *g, const char *fmt, ...)
{
    memmove(g->log[0], g->log[1], LOGW * (LOGN - 1));
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g->log[LOGN - 1], LOGW, fmt, ap);
    va_end(ap);
}


/* ------------------------------------------------------------------ */
/* Jimbo's dialogue. Keep every line under ~100 characters, ASCII only. */

typedef struct { const char *const *lines; int n; } Pool;
#define POOL(a) { a, (int)(sizeof(a) / sizeof((a)[0])) }

static const char *const L_TITLE[] = {
    "Heya, friend! It's me, Jimbo! Press A and let's play a totally normal game!",
    "Oh boy oh boy, a visitor! Sit down, sit down! Mind the shotgun.",
    "Welcome to Jimbo's Roulette! Please ignore the stains."};
static const char *const L_ROUND1[] = {
    "Hi hi hi! Quick rules: the gun goes bang. That's it. That's the rules.",
    "Round one! I made snacks. They're imaginary, like my license.",
    "Please keep all limbs inside the table at all times! Hehe!",
    "Let's play! I'm so excited I might wiggle. Wiggling now."};
static const char *const L_ROUND2[] = {
    "You won?! Don't tell my boss! I don't have one. Round two!",
    "Ooh, round two! I got new toys! Don't ask where I got them.",
    "Round two! Now with 100% more stuff and 0% more safety!"};
static const char *const L_ROUND3[] = {
    "Final round! The cables are fine. Probably. Look, don't touch them.",
    "Round three! I'm not nervous. My knees just do that.",
    "Last round! One more and I get to go home. I live here. Oh no."};
static const char *const L_LOAD[] = {
    "Shells go in! Shake shake shake! Wait, that's maracas.",
    "Loaded! I think. Lemme count... yep, that's a number!",
    "Fresh shells! They smell like a Tuesday.",
    "The gun is stuffed like a burrito. A dangerous burrito.",
    "I put the shells in randomly. Even I don't know! Ha!"};
static const char *const L_ITEMS[] = {
    "Ooh, shiny things! One for you, one for me, one for... also me.",
    "Presents! Everybody gets presents! Mostly dangerous ones.",
    "Goodies time! Please do not eat the goodies."};
static const char *const L_J_HIT_YOU[] = {
    "BANG! Oopsie daisy! Does that hurt? It looks like it hurts.",
    "Ooh, direct hit! I'm so sorry. (I'm not sorry.)",
    "Pew pew! Tag, you're it!",
    "Whoops, my finger slipped. On purpose.",
    "Ka-boom! That's the sound of me winning. Probably."};
static const char *const L_J_MISS_YOU[] = {
    "Click! Phew, lucky you! Lucky me too, I hate paperwork.",
    "Nothing! Dang. I mean, YAY for you!",
    "Ha, a dud! Like my jokes!",
    "Click! Don't worry, I'll get you next time. Aww, that sounded mean."};
static const char *const L_J_SELF_BLANK[] = {
    "Click! Told ya I'm lucky! My turn again!",
    "Blank! Muahaha, I'm invincible! ...for like a second.",
    "Nothing happened! I'm taking another turn, bye!",
    "Boop! Safe! I'm basically a wizard."};
static const char *const L_J_SELF_LIVE[] = {
    "OWWIE! That was my face! Why is it my face!",
    "Ow ow ow! I regret everything!",
    "Ouch! Note to self: stop shooting self.",
    "Oof! Who loaded this thing?! ...Oh, me."};
static const char *const L_P_HIT_J[] = {
    "Ow! Hey! That's not nice! ...That's actually totally fair.",
    "Ahh! You got me! I've been bamboozled!",
    "Ouch! My pancreas! ...I think that's my pancreas.",
    "Rude! Do you know how long I spent on this face?"};
static const char *const L_P_MISS_J[] = {
    "Haha, missed me! Nyah nyah!",
    "Click! The gun loves me!",
    "Blank! Thanks, gun! You're my best friend!",
    "Whew! My knees stopped knocking. Wait, no, they're back."};
static const char *const L_P_SELF_BLANK[] = {
    "Whoa, you shot yourself with nothing! Brave! Or dumb! I love it!",
    "Click! Big brain move, or no brain move. I can't tell!",
    "Ooh, spicy! Do it again! ...Please be safe. Not really."};
static const char *const L_P_SELF_LIVE[] = {
    "Oh no, you shot yourself! Was that on purpose? I have questions!",
    "Yikes! That's, uh, not how you're supposed to do it!",
    "Ouchie! Want a bandage? I don't have one. Sorry!"};
static const char *const L_ITEM_GLASS[] = {
    "Lemme peek... hmm... ooooh. I'm not telling!",
    "Tiny magnifying glass says hello! And also a secret!"};
static const char *const L_ITEM_BEER[] = {
    "Rack it! Burp. Sorry, that was the beer.",
    "Out you go, little shell! Don't write!"};
static const char *const L_ITEM_CIG[] = {
    "Smoke break! Ahh, plus one health! Don't tell my mom.",
    "Mmm, healthy lungs! ...No? Okay whatever."};
static const char *const L_ITEM_CUFFS[] = {
    "Gotcha! Time out for YOU. Hands up! Or wrists, whatever.",
    "Handcuffs! They're fuzzy. Okay, they're not."};
static const char *const L_ITEM_SAW[] = {
    "Zzzzt! Now it's a SHORT shotgun! Double the fun!",
    "Bzzzz! I love arts and crafts!"};
static const char *const L_ITEM_MED[] = {
    "Expired? It's like cheese! Aged! Gulp!",
    "Medicine time! Tastes like regret and grape."};
static const char *const L_ITEM_INVERTER[] = {
    "Flip flip flip! Reality is a pancake!",
    "Inverter! Shhh, it's very scientific."};
static const char *const L_ITEM_PHONE[] = {
    "Hello? Yes? ...uh huh... ...REALLY?! Okay, bye!",
    "Ring ring! The phone says... you wouldn't believe it."};
static const char *const L_ITEM_ADRENALINE[] = {
    "ADRENALINE! Gimme that! Mine now! Thanks, buddy!",
    "Finders keepers, losers weepers! Hehehe!"};
static const char *const L_PL_GLASS[] = {
    "Hey! No peeking! ...Okay, peek a little.",
    "Ooh, what did the glass say? Tell me tell me tell me!"};
static const char *const L_PL_CUFFS[] = {
    "Handcuffs?! On ME? That's, uh, kinda rude!",
    "Oh no, I'm stuck! This is fine. I'm fine. Help."};
static const char *const L_PL_SAW[] = {
    "Hey! Hey! Easy with the sawing! That's a nice gun!",
    "Is it getting shorter? It's getting shorter. Oh dear."};
static const char *const L_PL_STEAL[] = {
    "Hey! Thief! That's MY stuff! ...Okay, fair, I stole it first.",
    "Gasp! You took my thing! I'm telling!"};
static const char *const L_CABLE_J[] = {
    "Zzzt! My cables! Those were my GOOD cables!",
    "Uh oh, I'm all zappy! One more and I'm toast. Delicious toast."};
static const char *const L_CABLE_P[] = {
    "Zzzt! Your cables are cut! Don't worry, that's totally normal!",
    "Oooh, extra spicy now! One more hit and... well. You know."};
static const char *const L_WIN[] = {
    "You... you won?! Wow. Okay. I'm gonna go cry in the closet. Bye!",
    "No fair! I demand a rematch! ...Please? I'll bring snacks!"};
static const char *const L_LOSE[] = {
    "Hehe, I win! Do I get a trophy? Or a sandwich?",
    "Aww, you're out! Better luck next time, buddy!",
    "Yay! I won! ...Wait, is that bad? It feels bad. Eh!"};

static const Pool POOLS[JL_COUNT] = {
    [JL_TITLE] = POOL(L_TITLE), [JL_ROUND1] = POOL(L_ROUND1), [JL_ROUND2] = POOL(L_ROUND2),
    [JL_ROUND3] = POOL(L_ROUND3), [JL_LOAD] = POOL(L_LOAD), [JL_ITEMS] = POOL(L_ITEMS),
    [JL_J_HIT_YOU] = POOL(L_J_HIT_YOU), [JL_J_MISS_YOU] = POOL(L_J_MISS_YOU),
    [JL_J_SELF_BLANK] = POOL(L_J_SELF_BLANK), [JL_J_SELF_LIVE] = POOL(L_J_SELF_LIVE),
    [JL_P_HIT_J] = POOL(L_P_HIT_J), [JL_P_MISS_J] = POOL(L_P_MISS_J),
    [JL_P_SELF_BLANK] = POOL(L_P_SELF_BLANK), [JL_P_SELF_LIVE] = POOL(L_P_SELF_LIVE),
    [JL_ITEM_GLASS] = POOL(L_ITEM_GLASS), [JL_ITEM_BEER] = POOL(L_ITEM_BEER),
    [JL_ITEM_CIG] = POOL(L_ITEM_CIG), [JL_ITEM_CUFFS] = POOL(L_ITEM_CUFFS),
    [JL_ITEM_SAW] = POOL(L_ITEM_SAW), [JL_ITEM_MED] = POOL(L_ITEM_MED),
    [JL_ITEM_INVERTER] = POOL(L_ITEM_INVERTER), [JL_ITEM_PHONE] = POOL(L_ITEM_PHONE),
    [JL_ITEM_ADRENALINE] = POOL(L_ITEM_ADRENALINE),
    [JL_PL_GLASS] = POOL(L_PL_GLASS), [JL_PL_CUFFS] = POOL(L_PL_CUFFS),
    [JL_PL_SAW] = POOL(L_PL_SAW), [JL_PL_STEAL] = POOL(L_PL_STEAL),
    [JL_CABLE_J] = POOL(L_CABLE_J), [JL_CABLE_P] = POOL(L_CABLE_P),
    [JL_WIN] = POOL(L_WIN), [JL_LOSE] = POOL(L_LOSE),
};

int game_pool_size(int pool) { return POOLS[pool].n; }
const char *game_pool_line(int pool, int i) { return POOLS[pool].lines[i]; }

static void wait(Game *g, int frames)
{
    if (g->delay < frames) g->delay = frames;
}

/* Jimbo says a random line from the pool (chancePct = how often he speaks).
   The game pauses long enough for the line to be typed out and read. */
void game_speak(Game *g, int pool, int chancePct)
{
    const Pool *p = &POOLS[pool];
    if (p->n <= 0) return;
    if (chancePct < 100 && rand() % 100 >= chancePct) return;
    int idx = rand() % p->n;
    if (p->n > 1 && idx == g->lastLine[pool]) idx = (idx + 1) % p->n;
    g->lastLine[pool] = idx;
    snprintf(g->speech, sizeof g->speech, "%s", p->lines[idx]);
    g->speechAge = 0;
    g->speechSerial++;
    if (g->phase != PH_TITLE) {
        int len = (int)strlen(g->speech);
        int w = len * 3 / 2 + 45;
        wait(g, w > 190 ? 190 : w);
    }
}

/* ------------------------------------------------------------------ */

void game_new(Game *g)
{
    memset(g, 0, sizeof *g);
    g->round = 0;
    game_next_round(g);
}

void game_next_round(Game *g)
{
    g->round++;
    g->maxhp = (g->round == 1) ? 2 : 4;
    for (int s = 0; s < 2; s++) {
        g->hp[s] = g->maxhp;
        g->sudden[s] = false;
        g->cuffed[s] = false;
        for (int i = 0; i < NSLOTS; i++) g->items[s][i] = IT_NONE;
    }
    g->sawed = false;
    g->nshells = g->pos = 0;
    g->phase = PH_LOAD;
    wait(g, 90);
    game_sfx(g, SFX_ROUND);
    game_event(g, EV_ROUND, 0, g->round, 0, 0, 0);
    game_say(g, "=== ROUND %d ===  %d charges each.", g->round, g->maxhp);
    game_speak(g, g->round == 1 ? JL_ROUND1 : g->round == 2 ? JL_ROUND2 : JL_ROUND3, 100);
}

void game_load(Game *g)
{
    int n    = 2 + rand() % (MAXSH - 1);   /* 2..8 shells */
    int live = 1 + rand() % (n - 1);       /* at least 1 live and 1 blank */
    for (int i = 0; i < n; i++) g->shells[i] = (i < live);
    for (int i = n - 1; i > 0; i--) {      /* shuffle */
        int j = rand() % (i + 1);
        int t = g->shells[i]; g->shells[i] = g->shells[j]; g->shells[j] = t;
    }
    g->nshells = n; g->pos = 0;
    g->nlive0 = live; g->nblank0 = n - live;
    for (int s = 0; s < 2; s++) {
        for (int i = 0; i <= MAXSH; i++) g->known[s][i] = -1;
        g->bel[s][1] = live; g->bel[s][0] = n - live;
        g->unsure[s] = false;
        g->cuffed[s] = false;
    }
    g->sawed = false;

    game_sfx(g, SFX_LOAD);
    game_event(g, EV_LOAD, 0, n, 0, 0, 0);
    game_say(g, "Loaded: %d LIVE, %d BLANK.", live, n - live);

    if (g->round >= 2) {
        int per = (g->round == 2) ? 2 : 4;
        for (int s = 0; s < 2; s++) {
            for (int k = 0; k < per; k++) {
                int empty[NSLOTS], ne = 0;
                for (int i = 0; i < NSLOTS; i++)
                    if (g->items[s][i] == IT_NONE) empty[ne++] = i;
                if (!ne) break;
                g->items[s][empty[rand() % ne]] = 1 + rand() % (IT_COUNT - 1);
            }
        }
        game_sfx(g, SFX_DEAL);
        game_say(g, "%d items dealt to each side.", per);
        if (rand() % 100 < 35) game_speak(g, JL_ITEMS, 100);
        else game_speak(g, JL_LOAD, 60);
    }

    if (g->round < 2) game_speak(g, JL_LOAD, 60);
    g->turn = PLAYER;
    g->phase = PH_PLAYER;
    wait(g, 45);
}

/* ------------------------------------------------------------------ */

int game_find_item(const Game *g, int who, int item)
{
    for (int i = 0; i < NSLOTS; i++)
        if (g->items[who][i] == item) return i;
    return -1;
}

int game_cur_known(const Game *g, int who)
{
    if (g->pos >= g->nshells) return -1;
    int k = g->known[who][g->pos];
    if (k >= 0) return k;
    if (!g->unsure[who]) {
        if (g->bel[who][1] == 0 && g->bel[who][0] > 0) return 0;
        if (g->bel[who][0] == 0 && g->bel[who][1] > 0) return 1;
    }
    return -1;
}

bool game_can_use(const Game *g, int who, int item, const char **why)
{
    const char *w = NULL;
    switch (item) {
    case IT_CIG:
    case IT_MED:
        if (g->sudden[who]) w = "Cables cut: no healing.";
        else if (item == IT_CIG && g->hp[who] >= g->maxhp) w = "Already at full charge.";
        break;
    case IT_CUFFS:
        if (g->cuffed[1 - who]) w = "Already handcuffed.";
        break;
    case IT_SAW:
        if (g->sawed) w = "Already sawed off.";
        break;
    case IT_ADRENALINE:
        if (!game_can_steal(g, who)) w = "Nothing to steal.";
        break;
    default: break;
    }
    if (why) *why = w;
    return w == NULL;
}

bool game_can_steal(const Game *g, int who)
{
    for (int i = 0; i < NSLOTS; i++) {
        int t = g->items[1 - who][i];
        if (t != IT_NONE && t != IT_ADRENALINE && game_can_use(g, who, t, NULL))
            return true;
    }
    return false;
}

/* ------------------------------------------------------------------ */

static void hurt(Game *g, int who, int dmg)
{
    g->hp[who] -= dmg;
    g->hurt[who] = 40;
    game_event(g, EV_DAMAGE, who, dmg, 0, 0, 0);
    if (g->hp[who] <= 0) {
        if (g->round == 3 && !g->sudden[who]) {
            g->sudden[who] = true;
            g->hp[who] = 1;
            game_sfx(g, SFX_CABLE);
            game_say(g, "%s: cables cut! Next hit kills.", who_name(who));
            game_speak(g, who == DEALER ? JL_CABLE_J : JL_CABLE_P, 100);
        } else {
            g->hp[who] = 0;
        }
    }
}

static void heal(Game *g, int who, int n)
{
    int before = g->hp[who];
    g->hp[who] += n;
    if (g->hp[who] > g->maxhp) g->hp[who] = g->maxhp;
    if (g->hp[who] > before) game_event(g, EV_HEAL, who, g->hp[who] - before, 0, 0, 0);
}

static void eject(Game *g, int v)
{
    g->spentv[g->pos] = v;
    for (int s = 0; s < 2; s++)
        if (g->bel[s][v] > 0) g->bel[s][v]--;
    g->pos++;
}

static void apply_item(Game *g, int who, int t)
{
    int opp = 1 - who;
    switch (t) {
    case IT_GLASS: {
        int v = g->shells[g->pos];
        g->known[who][g->pos] = v;
        game_sfx(g, SFX_GLASS);
        game_event(g, EV_REVEAL, who, g->pos, 0, 0, 0);
        if (who == PLAYER) game_say(g, "The chamber is %s.", v ? "LIVE" : "BLANK");
        else game_say(g, "Jimbo squints at the chamber...");
        break;
    }
    case IT_BEER: {
        int v = g->shells[g->pos];
        game_sfx(g, SFX_RACK);
        game_event(g, EV_EJECT, who, v, g->pos, 0, 0);
        game_say(g, "%s rack%s the gun: %s shell ejected.", who_name(who),
                 verb_s(who), v ? "LIVE" : "BLANK");
        eject(g, v);
        break;
    }
    case IT_CIG:
        heal(g, who, 1);
        game_sfx(g, SFX_HEAL);
        game_say(g, "%s feel%s better. +1 charge.", who_name(who),
                 who == PLAYER ? "" : "s");
        break;
    case IT_CUFFS:
        g->cuffed[opp] = true;
        game_sfx(g, SFX_CUFFS);
        game_event(g, EV_CUFF, who, opp, 0, 0, 0);
        game_say(g, "%s %s handcuffed!", who_name(opp), opp == PLAYER ? "are" : "is");
        break;
    case IT_SAW:
        g->sawed = true;
        game_sfx(g, SFX_SAW);
        game_event(g, EV_SAW, who, 0, 0, 0, 0);
        game_say(g, "Barrel sawed off: double damage.");
        break;
    case IT_MED:
        if (rand() % 2) {
            heal(g, who, 2);
            game_sfx(g, SFX_HEAL);
            game_say(g, "Medicine works! %s +2 charges.", who_name(who));
        } else {
            game_sfx(g, SFX_BAD);
            game_say(g, "Bad medicine... %s -1 charge.", who_name(who));
            hurt(g, who, 1);
        }
        break;
    case IT_INVERTER: {
        int p = g->pos;
        for (int s = 0; s < 2; s++) {
            int kv = game_cur_known(g, s);
            if (kv >= 0) {
                if (g->bel[s][kv] > 0) g->bel[s][kv]--;
                g->bel[s][1 - kv]++;
                g->known[s][p] = 1 - kv;
            } else {
                g->unsure[s] = true;
            }
        }
        g->shells[p] = 1 - g->shells[p];
        game_sfx(g, SFX_INVERT);
        game_event(g, EV_FLIP, who, p, 0, 0, 0);
        game_say(g, "The current shell polarity is flipped.");
        break;
    }
    case IT_PHONE: {
        game_sfx(g, SFX_PHONE);
        int rem = g->nshells - g->pos;
        if (rem <= 1) {
            game_say(g, "%s: \"...no more shells to see.\"", who == PLAYER ? "Phone" : "Jimbo");
        } else {
            int k = 1 + rand() % (rem - 1);
            int v = g->shells[g->pos + k];
            g->known[who][g->pos + k] = v;
            if (who == PLAYER)
                game_say(g, "Shell #%d from now is %s.", k + 1, v ? "LIVE" : "BLANK");
            else
                game_say(g, "Jimbo listens to a burner phone.");
        }
        break;
    }
    default: break;
    }
}

bool game_use_item(Game *g, int who, int slot, int stealSlot)
{
    if (slot < 0 || slot >= NSLOTS) return false;
    int t = g->items[who][slot];
    if (t == IT_NONE) return false;
    if (!game_can_use(g, who, t, NULL)) return false;

    if (t == IT_ADRENALINE) {
        if (stealSlot < 0 || stealSlot >= NSLOTS) return false;
        int st = g->items[1 - who][stealSlot];
        if (st == IT_NONE || st == IT_ADRENALINE) return false;
        if (!game_can_use(g, who, st, NULL)) return false;
        g->items[who][slot] = IT_NONE;
        g->items[1 - who][stealSlot] = IT_NONE;
        game_sfx(g, SFX_ADRENALINE);
        game_event(g, EV_ITEM, who, IT_ADRENALINE, slot, 0, 0);
        game_event(g, EV_STEAL, who, st, stealSlot, 0, 0);
        game_say(g, "%s inject%s adrenaline, stealing %s!", who_name(who),
                 verb_s(who), item_name(st));
        apply_item(g, who, st);
        if (g->hp[0] > 0 && g->hp[1] > 0)
            game_speak(g, who == DEALER ? JL_ITEM_ADRENALINE : JL_PL_STEAL, 85);
    } else {
        g->items[who][slot] = IT_NONE;
        game_event(g, EV_ITEM, who, t, slot, 0, 0);
        game_say(g, "%s use%s %s.", who_name(who), verb_s(who), item_name(t));
        apply_item(g, who, t);
        if (g->hp[0] > 0 && g->hp[1] > 0) {
            if (who == DEALER) game_speak(g, JL_ITEM_NONE + t, 55);
            else if (t == IT_GLASS) game_speak(g, JL_PL_GLASS, 50);
            else if (t == IT_CUFFS) game_speak(g, JL_PL_CUFFS, 65);
            else if (t == IT_SAW)   game_speak(g, JL_PL_SAW, 65);
        }
    }
    wait(g, 55);
    return true;
}

void game_shoot(Game *g, int who, int target)
{
    int v = g->shells[g->pos];
    int dmg = g->sawed ? 2 : 1;
    const char *tn = (target == who) ? (who == PLAYER ? "yourself" : "himself")
                                     : (who == PLAYER ? "Jimbo" : "you");
    game_say(g, "%s fire%s at %s...", who_name(who), verb_s(who), tn);
    game_event(g, EV_SHOT, who, target, v, g->pos, dmg);
    eject(g, v);
    g->sawed = false;
    if (v) {
        game_sfx(g, SFX_BANG);
        game_say(g, "BANG! LIVE. %s take%s %d.", who_name(target),
                 target == PLAYER ? "" : "s", dmg);
        hurt(g, target, dmg);
    } else {
        game_sfx(g, SFX_CLICK);
        game_say(g, "click... BLANK.");
    }

    if (g->hp[0] > 0 && g->hp[1] > 0) {
        if (who == DEALER) {
            if (target == PLAYER) game_speak(g, v ? JL_J_HIT_YOU : JL_J_MISS_YOU, 75);
            else game_speak(g, v ? JL_J_SELF_LIVE : JL_J_SELF_BLANK, 75);
        } else {
            if (target == DEALER) game_speak(g, v ? JL_P_HIT_J : JL_P_MISS_J, 70);
            else game_speak(g, v ? JL_P_SELF_LIVE : JL_P_SELF_BLANK, 65);
        }
    }

    int next = (target == who && !v) ? who : 1 - who;
    if (g->hp[0] > 0 && g->hp[1] > 0 && next != who && g->cuffed[next]) {
        g->cuffed[next] = false;
        game_say(g, "%s %s cuffed and skip%s the turn.", who_name(next),
                 next == PLAYER ? "are" : "is", next == PLAYER ? "" : "s");
        next = who;
    }
    g->turn = next;
    wait(g, 75);
}

void game_after(Game *g)
{
    if (g->hp[DEALER] <= 0) {
        game_event(g, EV_KO, DEALER, g->round >= 3, 0, 0, 0);
        if (g->round >= 3) {
            g->phase = PH_WIN;
            game_sfx(g, SFX_WIN);
            game_say(g, "Jimbo falls. You survived!");
            game_speak(g, JL_WIN, 100);
        } else {
            game_say(g, "Round %d cleared.", g->round);
            game_next_round(g);
        }
        wait(g, 90);
        return;
    }
    if (g->hp[PLAYER] <= 0) {
        game_event(g, EV_KO, PLAYER, 0, 0, 0, 0);
        g->phase = PH_GAMEOVER;
        game_sfx(g, SFX_LOSE);
        game_say(g, "You died.");
        game_speak(g, JL_LOSE, 100);
        wait(g, 90);
        return;
    }
    if (g->pos >= g->nshells) {
        g->phase = PH_LOAD;
        game_say(g, "Shotgun empty. Reloading...");
        wait(g, 50);
        return;
    }
    g->phase = (g->turn == PLAYER) ? PH_PLAYER : PH_DEALER;
}

/* ------------------------------------------------------------------ */
/* Jimbo's AI: performs exactly one action (item or shot) per call.     */

static bool dtry(Game *g, int item)
{
    int s = game_find_item(g, DEALER, item);
    return s >= 0 && game_use_item(g, DEALER, s, -1);
}

void game_dealer_step(Game *g)
{
    const int D = DEALER, P = PLAYER;
    int rem = g->nshells - g->pos;
    int cur = game_cur_known(g, D);

    /* healing */
    if (!g->sudden[D]) {
        if (g->hp[D] < g->maxhp && dtry(g, IT_CIG)) return;
        if (g->hp[D] >= 2 && g->hp[D] <= g->maxhp - 2 && dtry(g, IT_MED)) return;
    }
    /* information */
    if (cur < 0 && rem > 1 && dtry(g, IT_GLASS)) return;
    if (rem > 2 && dtry(g, IT_PHONE)) return;
    /* turn a known blank into a live shell */
    if (cur == 0 && dtry(g, IT_INVERTER)) return;
    /* press an advantage on a known live shell */
    if (cur == 1) {
        if (!g->sawed && g->hp[P] >= 2 && dtry(g, IT_SAW)) return;
        if (rem > 1 && !g->cuffed[P] && dtry(g, IT_CUFFS)) return;
    }
    if (cur < 0) {
        if (rem > 1 && !g->cuffed[P] && rand() % 2 && dtry(g, IT_CUFFS)) return;
        if (rem > 1 && rand() % 2 && dtry(g, IT_BEER)) return;
    }
    /* adrenaline: steal something useful */
    int adr = game_find_item(g, D, IT_ADRENALINE);
    if (adr >= 0) {
        static const int pref[] = {IT_GLASS, IT_CIG, IT_CUFFS, IT_SAW, IT_INVERTER,
                                   IT_BEER, IT_PHONE, IT_MED};
        for (unsigned k = 0; k < sizeof pref / sizeof pref[0]; k++) {
            if (pref[k] == IT_GLASS && cur >= 0) continue;
            int sl = game_find_item(g, P, pref[k]);
            if (sl >= 0 && game_can_use(g, D, pref[k], NULL)
                && game_use_item(g, D, adr, sl)) return;
        }
    }
    /* shoot */
    int target;
    if (cur == 1) target = P;
    else if (cur == 0) target = D;
    else if (g->unsure[D]) target = rand() % 2 ? P : D;
    else if (g->bel[D][1] > g->bel[D][0]) target = P;
    else if (g->bel[D][1] < g->bel[D][0]) target = D;
    else target = rand() % 2 ? P : D;
    game_shoot(g, D, target);
}
