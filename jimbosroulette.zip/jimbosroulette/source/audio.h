// Jimbo's Roulette - audio (ndsp). Safe to call even when sound is unavailable.
#ifndef AUDIO_H
#define AUDIO_H
#include <stdbool.h>

void audio_init(void);
void audio_exit(void);
bool audio_ok(void);            // false if DSP firmware is missing
void audio_play(int sfx);       // sfx = Sfx enum from game.h
void audio_blip(float pitch);   // Jimbo's voice blip (1.0 = normal pitch)
void audio_toggle_music(void);
bool audio_music_on(void);

#endif
