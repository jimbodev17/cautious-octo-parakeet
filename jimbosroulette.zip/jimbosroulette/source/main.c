// Jimbo's Roulette - UI (citro2d). Game rules live in game.c.
#include <3ds.h>
#include <citro2d.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "audio.h"
#include "game.h"

#define COL(r, g, b) C2D_Color32((r), (g), (b), 255)
#define COLA(r, g, b, a) C2D_Color32((r), (g), (b), (a))
#define PI_F 3.14159265f

static C2D_TextBuf g_buf;
static C2D_SpriteSheet g_sheet;
static C3D_RenderTarget *g_top, *g_bot;

static const u32 C_BG    = 0xFF1C1814; /* ABGR: dark */
static int g_cur  = 0;   /* player item cursor */
static int g_scur = 0;   /* dealer item cursor while stealing */
static float g_z = 0.5f; /* depth used by text() */
static int   g_frame = 0;

static u32 alpha(u32 c, int a)
{
    if (a < 0) a = 0;
    if (a > 255) a = 255;
    return (c & 0x00FFFFFFu) | ((u32)a << 24);
}


/* ------------------------------------------------------------ drawing */

static void text(float x, float y, float s, u32 col, const char *fmt, ...)
{
    char tmp[128];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(tmp, sizeof tmp, fmt, ap);
    va_end(ap);
    C2D_Text t;
    C2D_TextParse(&t, g_buf, tmp);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, g_z, s, s, col);
}

static void textc(float cx, float y, float s, u32 col, const char *fmt, ...)
{
    char tmp[128];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(tmp, sizeof tmp, fmt, ap);
    va_end(ap);
    C2D_Text t;
    C2D_TextParse(&t, g_buf, tmp);
    C2D_TextOptimize(&t);
    float w, h;
    C2D_TextGetDimensions(&t, s, s, &w, &h);
    C2D_DrawText(&t, C2D_WithColor, cx - w / 2, y, g_z, s, s, col);
}

static void frame(float x, float y, float w, float h, float t, u32 col)
{
    C2D_DrawRectSolid(x, y, 0.4f, w, t, col);
    C2D_DrawRectSolid(x, y + h - t, 0.4f, w, t, col);
    C2D_DrawRectSolid(x, y, 0.4f, t, h, col);
    C2D_DrawRectSolid(x + w - t, y, 0.4f, t, h, col);
}

static bool inrect(int px, int py, int x, int y, int w, int h)
{
    return px >= x && px < x + w && py >= y && py < y + h;
}

static u32 item_col(int t)
{
    switch (t) {
    case IT_GLASS:      return COL(90, 170, 220);
    case IT_BEER:       return COL(220, 160, 40);
    case IT_CIG:        return COL(200, 120, 90);
    case IT_CUFFS:      return COL(160, 160, 170);
    case IT_SAW:        return COL(200, 80, 70);
    case IT_MED:        return COL(110, 190, 110);
    case IT_INVERTER:   return COL(180, 110, 210);
    case IT_PHONE:      return COL(80, 200, 190);
    case IT_ADRENALINE: return COL(230, 90, 150);
    default:            return COL(50, 50, 55);
    }
}


/* ------------------------------------------------------ Jimbo's bubble */

#define BX 270
#define BY 36
#define BW 126

static int   s_serial = -1, s_nl = 0, s_ls[10], s_le[10];
static float s_lh = 12.0f;

static float tw(const char *str, int n, float sc, float *hOut)
{
    char tmp[96];
    if (n > 95) n = 95;
    memcpy(tmp, str, n);
    tmp[n] = 0;
    C2D_Text t;
    C2D_TextParse(&t, g_buf, tmp);
    float w, h;
    C2D_TextGetDimensions(&t, sc, sc, &w, &h);
    if (hOut) *hOut = h;
    return w;
}

/* greedy word wrap, computed once per new line of dialogue */
static void speech_layout(const Game *g, float sc, float maxw)
{
    const char *s = g->speech;
    int len = (int)strlen(s);
    float sp = tw("a a", 3, sc, &s_lh) - tw("aa", 2, sc, NULL);
    s_nl = 0;
    int i = 0;
    while (i < len && s_nl < 10) {
        int ls = i, le = i;
        float lw = 0;
        while (i < len) {
            int ws = i;
            while (i < len && s[i] != ' ') i++;
            float w = tw(s + ws, i - ws, sc, NULL);
            if (le != ls && lw + sp + w > maxw) { i = ws; break; }
            lw += (le == ls) ? w : sp + w;
            le = i;
            while (i < len && s[i] == ' ') i++;
        }
        s_ls[s_nl] = ls;
        s_le[s_nl] = le;
        s_nl++;
    }
}

static int speech_shown(const Game *g)
{
    int len = (int)strlen(g->speech);
    int n = g->speechAge * 2 / 3;      /* ~40 characters per second */
    return n > len ? len : n;
}

static void draw_speech(const Game *g)
{
    int len = (int)strlen(g->speech);
    if (!len || g->speechAge > len * 3 / 2 + 300) return;
    const float sc = 0.42f;
    if (g->speechSerial != s_serial) {
        speech_layout(g, sc, BW - 14);
        s_serial = g->speechSerial;
    }
    int shown = speech_shown(g);
    float lh = s_lh * 1.05f, bh = s_nl * lh + 12;
    u32 ink = COL(25, 25, 30);

    C2D_DrawRectSolid(BX, BY, 0.75f, BW, bh, COL(252, 250, 242));
    frame(BX, BY, BW, bh, 2, ink);
    C2D_DrawTriangle(BX + 1, BY + 12, COL(252, 250, 242), BX + 1, BY + 28, COL(252, 250, 242),
                     BX - 11, BY + 20, COL(252, 250, 242), 0.76f);
    g_z = 0.8f;
    for (int i = 0; i < s_nl; i++) {
        int cnt = s_le[i] - s_ls[i];
        int vis = shown - s_ls[i];
        if (vis > cnt) vis = cnt;
        if (vis <= 0) continue;
        char tmp[96];
        if (vis > 95) vis = 95;
        memcpy(tmp, g->speech + s_ls[i], vis);
        tmp[vis] = 0;
        text(BX + 7, BY + 6 + i * lh, sc, ink, "%s", tmp);
    }
    g_z = 0.5f;
}


/* ======================================================== animations */
/* All purely visual: they react to GameEvents and never touch the rules. */

#define NPOP 8
#define NCARD 6
#define NSHELL 6
#define CARD_LIFE 80

typedef struct { int t, life; float x, y, vy, sc; u32 col; char txt[16]; } Pop;
typedef struct { int t, who, item, life, born; const char *verb; } Card;
typedef struct { float x, y, vx, vy; int t, live; } ShellFx;

static Pop     g_pops[NPOP];
static Card    g_cards[NCARD];
static ShellFx g_shellfx[NSHELL];
static int g_shake, g_flashW, g_flashR;
static int g_bangT = -1, g_bangKind, g_bangTarget;     /* kind: 0 click, 1 bang, 2 boom */
static int g_loadT = -1, g_loadN;
static int g_bannerT = -1, g_bannerRound;
static int g_ghostT[2], g_ghostFrom[2], g_healT[2], g_lastHp[2];
static int g_slotT[2][NSLOTS], g_slotItem[2][NSLOTS];
static int g_pulseT[MAXSH + 1], g_pulseKind[MAXSH + 1];
static int g_fHit, g_fHitDir = 1, g_fHappy, g_fLunge, g_fNod, g_fKO = -1, g_koFinal;

static void anim_reset(void)
{
    memset(g_pops, 0, sizeof g_pops);
    for (int i = 0; i < NCARD; i++) { g_cards[i].t = 999; g_cards[i].life = CARD_LIFE; g_cards[i].born = -1; }
    for (int i = 0; i < NSHELL; i++) g_shellfx[i].t = -1;
    g_shake = g_flashW = g_flashR = 0;
    g_bangT = g_loadT = g_bannerT = -1;
    memset(g_ghostT, 0, sizeof g_ghostT);
    memset(g_ghostFrom, 0, sizeof g_ghostFrom);
    memset(g_healT, 0, sizeof g_healT);
    memset(g_slotT, 0, sizeof g_slotT);
    memset(g_pulseT, 0, sizeof g_pulseT);
    g_fHit = g_fHappy = g_fLunge = g_fNod = 0;
    g_fKO = -1;
    g_koFinal = 0;
}

static void add_pop(float x, float y, u32 col, float sc, const char *fmt, ...)
{
    int k = 0;
    for (int i = 0; i < NPOP; i++) if (g_pops[i].life == 0) { k = i; break; }
    Pop *p = &g_pops[k];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(p->txt, sizeof p->txt, fmt, ap);
    va_end(ap);
    p->t = 0; p->life = 55; p->x = x; p->y = y; p->vy = -1.2f; p->sc = sc; p->col = col;
}

static void add_card(int who, int item, const char *verb)
{
    int k = -1, chainStart = 0;
    for (int i = 0; i < NCARD; i++) {
        Card *c = &g_cards[i];
        if (c->t <= c->life && c->who == who) {
            if (c->born == g_frame) {            /* same action (e.g. Adrenaline + stolen item): show in turn */
                c->life = 45;
                if (c->t - 45 < chainStart) chainStart = c->t - 45;
            } else {
                c->t = 999;                      /* older card: replaced */
            }
        }
    }
    for (int i = 0; i < NCARD; i++) if (g_cards[i].t > g_cards[i].life) { k = i; break; }
    if (k < 0) k = 0;
    Card *c = &g_cards[k];
    c->who = who; c->item = item; c->verb = verb;
    c->life = CARD_LIFE; c->born = g_frame; c->t = chainStart;
}

static void spawn_shell(const Game *g, int pos, int live)
{
    int k = 0;
    for (int i = 0; i < NSHELL; i++) if (g_shellfx[i].t < 0) { k = i; break; }
    ShellFx *f = &g_shellfx[k];
    f->x = 200 - g->nshells * 11.0f + pos * 22 + 9;
    f->y = 166;
    f->vx = ((rand() & 1) ? 1.0f : -1.0f) * (1.5f + (rand() % 25) / 10.0f);
    f->vy = -7.0f - (rand() % 20) / 10.0f;
    f->t = 0; f->live = live;
}

static void anim_event(const Game *g, const GameEvent *e)
{
    switch (e->type) {
    case EV_SHOT: {
        int target = e->a, live = e->b;
        spawn_shell(g, e->c, live);
        g_bangT = 0;
        g_bangKind = live ? (e->d > 1 ? 2 : 1) : 0;
        g_bangTarget = target;
        if (live) {
            g_flashW = 7;
            g_shake = 18;
            if (target == PLAYER) g_flashR = 28;
            else { g_fHit = 25; g_fHitDir = (rand() & 1) ? 1 : -1; }
        }
        if (e->who == DEALER) {
            if (target == PLAYER) g_fLunge = 22;
            else if (!live) g_fHappy = 30;
        }
        break;
    }
    case EV_EJECT:
        spawn_shell(g, e->b, e->a);
        break;
    case EV_ITEM:
        add_card(e->who, e->a, e->who == PLAYER ? "YOU USE" : "JIMBO USES");
        if (e->b >= 0 && e->b < NSLOTS) { g_slotT[e->who][e->b] = 20; g_slotItem[e->who][e->b] = e->a; }
        if (e->who == DEALER) g_fNod = 18;
        break;
    case EV_STEAL:
        add_card(e->who, e->a, e->who == PLAYER ? "YOU STEAL" : "JIMBO STEALS");
        if (e->b >= 0 && e->b < NSLOTS) { g_slotT[1 - e->who][e->b] = 20; g_slotItem[1 - e->who][e->b] = e->a; }
        break;
    case EV_REVEAL:
        if (e->who == PLAYER && e->a <= MAXSH) { g_pulseT[e->a] = 30; g_pulseKind[e->a] = 0; }
        break;
    case EV_FLIP:
        if (e->a <= MAXSH) { g_pulseT[e->a] = 30; g_pulseKind[e->a] = 1; }
        break;
    case EV_LOAD:
        g_loadT = 0; g_loadN = e->a;
        break;
    case EV_ROUND:
        g_bannerT = 0; g_bannerRound = e->a;
        break;
    case EV_CUFF:
        if (e->a == DEALER) add_pop(150, 48, COL(150, 200, 255), 0.55f, "CUFFED!");
        else add_pop(70, 160, COL(150, 200, 255), 0.55f, "CUFFED!");
        break;
    case EV_DAMAGE:
        g_ghostT[e->who] = 30;
        g_ghostFrom[e->who] = g_lastHp[e->who];
        if (e->who == DEALER) add_pop(132, 30, COL(255, 80, 70), 0.9f, "-%d", e->a);
        else add_pop(78, 176, COL(255, 80, 70), 0.9f, "-%d", e->a);
        break;
    case EV_HEAL:
        g_healT[e->who] = 30;
        if (e->who == DEALER) add_pop(132, 30, COL(120, 255, 140), 0.9f, "+%d", e->a);
        else add_pop(78, 176, COL(120, 255, 140), 0.9f, "+%d", e->a);
        break;
    case EV_KO:
        if (e->who == DEALER) { g_fKO = 0; g_koFinal = e->a; }
        else { g_flashR = 40; g_shake = 24; }
        break;
    default: break;
    }
}

static void anim_update(void)
{
    if (g_shake > 0) g_shake--;
    if (g_flashW > 0) g_flashW--;
    if (g_flashR > 0) g_flashR--;
    if (g_bangT >= 0 && ++g_bangT > 55) g_bangT = -1;
    if (g_loadT >= 0 && ++g_loadT > g_loadN * 5 + 14) g_loadT = -1;
    if (g_bannerT >= 0 && ++g_bannerT > 100) g_bannerT = -1;
    for (int w = 0; w < 2; w++) {
        if (g_ghostT[w] > 0) g_ghostT[w]--;
        if (g_healT[w] > 0) g_healT[w]--;
        for (int i = 0; i < NSLOTS; i++) if (g_slotT[w][i] > 0) g_slotT[w][i]--;
    }
    for (int i = 0; i <= MAXSH; i++) if (g_pulseT[i] > 0) g_pulseT[i]--;
    for (int i = 0; i < NPOP; i++) {
        Pop *p = &g_pops[i];
        if (!p->life) continue;
        p->t++; p->y += p->vy; p->vy *= 0.97f;
        if (p->t >= p->life) p->life = 0;
    }
    for (int i = 0; i < NCARD; i++) if (g_cards[i].t <= g_cards[i].life) g_cards[i].t++;
    for (int i = 0; i < NSHELL; i++) {
        ShellFx *f = &g_shellfx[i];
        if (f->t < 0) continue;
        f->x += f->vx; f->y += f->vy; f->vy += 0.55f;
        if (++f->t > 55) f->t = -1;
    }
    if (g_fHit > 0) g_fHit--;
    if (g_fHappy > 0) g_fHappy--;
    if (g_fLunge > 0) g_fLunge--;
    if (g_fNod > 0) g_fNod--;
    if (g_fKO >= 0) {
        g_fKO++;
        if (!g_koFinal && g_fKO > 120) g_fKO = -1;
        if (g_koFinal && g_fKO > 100) g_fKO = 100;
    }
}

/* ---- charges: flash red when lost, green when healed ---- */
static void bolts(float x, float y, const Game *g, int who)
{
    int hp = g->hp[who];
    for (int i = 0; i < g->maxhp; i++) {
        float bx = x + i * 17;
        if (i < hp) {
            u32 c = g->sudden[who] ? COL(150, 150, 150) : COL(255, 214, 40);
            if (g_healT[who] > 0 && ((g_healT[who] >> 2) & 1)) c = COL(120, 255, 140);
            C2D_DrawRectSolid(bx, y, 0.4f, 13, 18, c);
        } else if (g_ghostT[who] > 0 && i < g_ghostFrom[who]) {
            u32 c = ((g_ghostT[who] >> 2) & 1) ? COL(255, 255, 255) : COL(230, 50, 40);
            float k = g_ghostT[who] / 30.0f;                 /* shrinks away */
            C2D_DrawRectSolid(bx + (1 - k) * 6, y + (1 - k) * 9, 0.4f, 13 * k, 18 * k, c);
        } else {
            frame(bx, y, 13, 18, 2, COL(70, 70, 70));
        }
    }
}

static void arrow(float x, float y)
{
    float sh = (0.5f + 0.5f * sinf(g_frame * 0.25f)) * 4;
    u32 c = COL(255, 230, 90);
    C2D_DrawTriangle(x + sh, y - 7, c, x + sh, y + 7, c, x - 9 + sh, y, c, 0.5f);
}

/* ---- Jimbo: idle bob, talking wobble, hit, lunge, happy hop, KO ---- */
static void draw_face(const Game *g)
{
    C2D_Image img = C2D_SpriteSheetGetImage(g_sheet, 0);
    float fr = (float)g_frame;
    float x = 200, y = 68, ang = 0, sc = 1.0f;
    y += sinf(fr * 0.05f) * 3.0f;

    int len = (int)strlen(g->speech);
    if (len && speech_shown(g) < len) {                      /* talking */
        ang += sinf(fr * 0.45f) * 0.06f;
        y -= fabsf(sinf(fr * 0.3f)) * 3.0f;
    }
    if (g_fHit > 0) {
        float k = g_fHit / 25.0f;
        ang += g_fHitDir * 0.5f * k * cosf((25 - g_fHit) * 0.5f);
        x += ((g_fHit & 2) ? 6.0f : -6.0f) * k;
    }
    if (g_fHappy > 0) y -= fabsf(sinf((30 - g_fHappy) * 0.35f)) * 20.0f * (g_fHappy / 30.0f);
    if (g_fLunge > 0) sc *= 1.0f + 0.14f * sinf(PI_F * (22 - g_fLunge) / 22.0f);
    if (g_fNod > 0) y += sinf(PI_F * (18 - g_fNod) / 18.0f) * 6.0f;
    if (g->phase == PH_GAMEOVER) {                           /* victory dance */
        y -= fabsf(sinf(fr * 0.2f)) * 16.0f;
        ang += sinf(fr * 0.2f) * 0.12f;
    }

    float grey = 0.0f;
    if (g_fKO >= 0) {
        float t = (float)g_fKO;
        if (g_koFinal) {                                     /* topples over and stays down */
            float p = t > 40 ? 1.0f : t / 40.0f;
            ang = p * 1.5708f;
            y += p * 55.0f;
            grey = 0.5f;
        } else if (t < 60) {                                 /* spins away... */
            float p = t / 60.0f;
            ang = p * 12.5f;
            y += p * p * 260.0f;
        } else if (t < 90) {
            y = 400;                                         /* off screen */
        } else {                                             /* ...and pops back up */
            float p = (t - 90) / 30.0f;
            y += (1 - p) * (1 - p) * 140.0f;
            sc *= 1.0f + 0.1f * sinf(PI_F * p);
        }
    }

    C2D_ImageTint tint;
    if (g_fKO >= 0 && g_koFinal) C2D_PlainImageTint(&tint, COL(120, 120, 130), grey);
    else C2D_PlainImageTint(&tint, COL(255, 70, 70), g->hurt[DEALER] > 0 ? 0.6f : 0.0f);

    C2D_DrawParams p;
    memset(&p, 0, sizeof p);
    p.pos.x = x; p.pos.y = y;                    /* position of the pivot (face centre) */
    p.pos.w = 128 * sc; p.pos.h = 128 * sc;
    p.center.x = p.pos.w / 2; p.center.y = p.pos.h / 2;
    p.depth = 0.3f;
    p.angle = ang;
    C2D_DrawImage(img, &p, &tint);
}

/* ---- top-screen effects: item cards, popups, BANG, shells, banner, flashes ---- */
static void draw_fx(const Game *g)
{
    (void)g;
    /* flying shells */
    for (int i = 0; i < NSHELL; i++) {
        ShellFx *f = &g_shellfx[i];
        if (f->t < 0) continue;
        bool flat = (f->t / 4) & 1;
        float w = flat ? 14 : 8, h = flat ? 8 : 14;
        int a = f->t > 40 ? (55 - f->t) * 255 / 15 : 255;
        u32 body = f->live ? COL(210, 60, 50) : COL(110, 130, 160);
        C2D_DrawRectSolid(f->x - w / 2, f->y - h / 2, 0.65f, w, h, alpha(body, a));
        if (flat) C2D_DrawRectSolid(f->x + w / 2 - 5, f->y - 4, 0.66f, 5, 8, alpha(COL(205, 165, 70), a));
        else      C2D_DrawRectSolid(f->x - 4, f->y + h / 2 - 5, 0.66f, 8, 5, alpha(COL(205, 165, 70), a));
    }

    /* item cards slide in beside whoever used the item */
    for (int i = 0; i < NCARD; i++) {
        const Card *c = &g_cards[i];
        if (c->t < 0 || c->t > c->life) continue;
        float x = 8, y = (c->who == DEALER) ? 66 : 136;
        if (c->t < 10) { float p = 1 - c->t / 10.0f; x -= 130 * p * p; }
        else if (c->t > c->life - 12) { float p = (c->t - (c->life - 12)) / 12.0f; x -= 130 * p * p; }
        C2D_DrawRectSolid(x, y, 0.55f, 112, 40, item_col(c->item));
        frame(x, y, 112, 40, 2, COL(255, 255, 255));
        g_z = 0.6f;
        textc(x + 56, y + 3, 0.36f, COL(10, 10, 10), "%s", c->verb);
        textc(x + 56, y + 18, 0.4f, COL(10, 10, 10), "%s", item_name(c->item));
        g_z = 0.5f;
    }

    /* floating -1 / +1 */
    g_z = 0.7f;
    for (int i = 0; i < NPOP; i++) {
        const Pop *p = &g_pops[i];
        if (!p->life) continue;
        int a = (p->t > p->life - 15) ? (p->life - p->t) * 255 / 15 : 255;
        textc(p->x + 1, p->y + 1, p->sc, alpha(COL(0, 0, 0), a / 2), "%s", p->txt);
        textc(p->x, p->y, p->sc, alpha(p->col, a), "%s", p->txt);
    }

    /* BANG! / BOOM! (sawed-off) / *click* */
    if (g_bangT >= 0) {
        const char *w = g_bangKind == 2 ? "BOOM!" : g_bangKind == 1 ? "BANG!" : "*click*";
        float t = (float)g_bangT;
        float pop = fmaxf(0.0f, 1.0f - t / 8.0f);
        float sc = g_bangKind ? (1.3f + 0.9f * pop) * (g_bangKind == 2 ? 1.25f : 1.0f) : 0.8f + 0.3f * pop;
        int life = g_bangKind ? 50 : 40;
        int a = t > life - 12 ? (int)(255 * (life - t) / 12) : 255;
        float cy = (g_bangTarget == DEALER ? 36.0f : 98.0f) - (g_bangKind ? 0.0f : t * 0.3f);
        float jx = (g_bangKind && t < 10) ? ((g_frame & 1) ? 3.0f : -3.0f) : 0.0f;
        g_z = 0.8f;
        textc(200 + jx + 2, cy + 2, sc, alpha(COL(0, 0, 0), a * 3 / 4), "%s", w);
        textc(200 + jx, cy, sc, alpha(g_bangKind ? COL(255, 70, 50) : COL(200, 200, 210), a), "%s", w);
    }

    /* round banner */
    if (g_bannerT >= 0) {
        float t = (float)g_bannerT, x = 200;
        if (t < 18) { float p = t / 18.0f; x = 200 + (1 - p) * (1 - p) * 280; }
        else if (t > 82) { float p = (t - 82) / 18.0f; x = 200 - p * p * 300; }
        C2D_DrawRectSolid(0, 86, 0.60f, 400, 48, COLA(0, 0, 0, 205));
        C2D_DrawRectSolid(0, 86, 0.61f, 400, 3, COL(220, 50, 40));
        C2D_DrawRectSolid(0, 131, 0.61f, 400, 3, COL(220, 50, 40));
        g_z = 0.62f;
        textc(x, 94, 1.1f, COL(255, 255, 255), "ROUND %d", g_bannerRound);
    }
    g_z = 0.5f;

    /* screen flashes */
    if (g_flashR > 0) C2D_DrawRectSolid(0, 0, 0.94f, 400, 240, alpha(COL(220, 20, 20), g_flashR * 110 / 28));
    if (g_flashW > 0) C2D_DrawRectSolid(0, 0, 0.95f, 400, 240, alpha(COL(255, 255, 255), g_flashW * 200 / 7));
}


/* item name that fits a slot: long names split onto two lines */
static void item_label(float cx, float y, float h, float sc, int t)
{
    const char *n = item_name(t);
    const char *sp = strchr(n, ' ');
    if (!sp) { textc(cx, y + h / 2 - 8, sc, COL(10, 10, 10), "%s", n); return; }
    char a[24];
    int len = (int)(sp - n);
    if (len > 23) len = 23;
    memcpy(a, n, len);
    a[len] = 0;
    textc(cx, y + h / 2 - 17, sc, COL(10, 10, 10), "%s", a);
    textc(cx, y + h / 2 - 2, sc, COL(10, 10, 10), "%s", sp + 1);
}

/* ---------------------------------------------------------------- top */

static void draw_top(const Game *g)
{
    C2D_TargetClear(g_top, C_BG);
    C2D_SceneBegin(g_top);
    C2D_ViewReset();
    if (g_shake > 0)
        C2D_ViewTranslate(sinf(g_frame * 2.1f) * g_shake * 0.35f, cosf(g_frame * 2.9f) * g_shake * 0.35f);

    draw_face(g);

    bool jturn = (g->phase == PH_DEALER);
    bool pturn = (g->phase == PH_PLAYER || g->phase == PH_STEAL);
    float pulse = 0.5f + 0.5f * sinf(g_frame * 0.2f);

    /* Jimbo HUD */
    text(8, 4, 0.5f, jturn ? COL(255, 230, 120) : COL(230, 230, 230), "JIMBO");
    if (jturn) arrow(64, 13);
    bolts(8, 24, g, DEALER);
    if (g->cuffed[DEALER]) text(8, 46, 0.45f, COL(150 + (int)(pulse * 60), 200, 255), "CUFFED");
    if (g->round > 0) text(330, 4, 0.5f, COL(230, 230, 230), "ROUND %d", g->round);
    if (g->sawed) text(298, 22, 0.45f, COL(255, 90 + (int)(pulse * 100), 60), "SAWED-OFF x2");

    /* load info + shell tracker */
    if (g->nshells > 0) {
        textc(200, 134, 0.5f, COL(230, 230, 230), "LOAD: %d LIVE  /  %d BLANK", g->nlive0, g->nblank0);
        int n = g->nshells;
        float x0 = 200 - n * 11.0f;
        for (int i = 0; i < n; i++) {
            float bx = x0 + i * 22, by = 154;
            int a = 255;
            if (g_loadT >= 0) {                               /* shells drop in one by one */
                float ti = (float)(g_loadT - i * 5);
                if (ti < 0) continue;
                if (ti < 10) { float p = ti / 10.0f; by -= (1 - p) * (1 - p) * 40; a = (int)(255 * p); }
            }
            if (i < g->pos) {
                u32 c = g->spentv[i] ? COL(210, 60, 50) : COL(110, 130, 160);
                C2D_DrawRectSolid(bx, by, 0.4f, 18, 24, alpha(c, a));
                C2D_DrawRectSolid(bx, by, 0.45f, 18, 24, COLA(0, 0, 0, 90));
            } else {
                int k = (i == g->pos) ? game_cur_known(g, PLAYER) : g->known[PLAYER][i];
                if (k >= 0) {
                    C2D_DrawRectSolid(bx, by, 0.4f, 18, 24, alpha(k ? COL(210, 60, 50) : COL(110, 130, 160), a));
                } else {
                    C2D_DrawRectSolid(bx, by, 0.4f, 18, 24, alpha(COL(60, 60, 66), a));
                    text(bx + 5, by + 3, 0.5f, alpha(COL(160, 160, 170), a), "?");
                }
            }
            if (i == g->pos && g->pos < n)
                frame(bx - 2, by - 2, 22, 28, 2, alpha(COL(255, 255, 255), 150 + (int)(pulse * 105)));
            if (g_pulseT[i] > 0) {                            /* magnifier / inverter ripple */
                float k = 1 - g_pulseT[i] / 30.0f, gr = k * 9;
                u32 pc = g_pulseKind[i] ? COL(190, 110, 230) : COL(255, 255, 255);
                frame(bx - 2 - gr, by - 2 - gr, 22 + 2 * gr, 28 + 2 * gr, 2, alpha(pc, (int)((1 - k) * 255)));
            }
        }
    }

    /* player HUD */
    text(8, 182, 0.5f, pturn ? COL(255, 230, 120) : COL(230, 230, 230), "YOU");
    if (pturn) arrow(46, 191);
    bolts(8, 202, g, PLAYER);
    if (g->cuffed[PLAYER]) text(8, 224, 0.45f, COL(150 + (int)(pulse * 60), 200, 255), "CUFFED");

    /* log */
    for (int i = 0; i < LOGN; i++) {
        int shade = 110 + i * 48;
        text(96, 184 + i * 14, 0.45f, COL(shade, shade, shade), "%s", g->log[i]);
    }

    /* overlays (kept below the face so Jimbo stays visible) */
    if (g->phase == PH_TITLE) {
        C2D_DrawRectSolid(0, 134, 0.6f, 400, 106, COLA(0, 0, 0, 190));
        g_z = 0.7f;
        textc(200, 138, 0.85f, COL(255, 255, 255), "JIMBO'S ROULETTE");
        textc(200, 168, 0.5f, COL(230, 90, 70), "3DS EDITION");
        textc(200, 192, 0.5f, alpha(COL(220, 220, 220), 150 + (int)(pulse * 105)), "Press A or tap the touch screen");
        if (!audio_ok())
            textc(200, 216, 0.42f, COL(230, 170, 60), "Sound off: dspfirm.cdc not found on SD card");
        else
            textc(200, 216, 0.42f, COL(150, 150, 150), "SELECT: music on/off");
        g_z = 0.5f;
    } else if (g->phase == PH_GAMEOVER || g->phase == PH_WIN) {
        bool win = (g->phase == PH_WIN);
        C2D_DrawRectSolid(0, 134, 0.6f, 400, 72, COLA(0, 0, 0, 200));
        g_z = 0.7f;
        if (win) textc(200, 138, 0.9f, COL(110, 220, 110), "YOU SURVIVED");
        else     textc(200, 138, 0.9f, COL(220, 50, 40), "YOU DIED");
        textc(200, 176, 0.5f, COL(220, 220, 220), "Press A or tap to return to the title");
        g_z = 0.5f;
    }

    draw_fx(g);
    draw_speech(g);
}

/* ------------------------------------------------------------- bottom */

static void draw_bottom(const Game *g)
{
    C2D_TargetClear(g_bot, C_BG);
    C2D_SceneBegin(g_bot);
    C2D_ViewReset();
    if (g_flashR > 0 || g_shake > 0)
        C2D_ViewTranslate(sinf(g_frame * 2.3f) * g_shake * 0.25f, cosf(g_frame * 2.7f) * g_shake * 0.25f);

    bool stealing = (g->phase == PH_STEAL);
    bool myturn = (g->phase == PH_PLAYER) && g->delay == 0;
    float pulse = 0.5f + 0.5f * sinf(g_frame * 0.15f);

    /* Jimbo's items (small row) */
    for (int i = 0; i < NSLOTS; i++) {
        float x = 6 + i * 39, y = 6;
        int t = g->items[DEALER][i];
        C2D_DrawRectSolid(x, y, 0.3f, 36, 34, item_col(t));
        if (t) textc(x + 18, y + 9, 0.45f, COL(10, 10, 10), "%s", item_short(t));
        if (stealing && i == g_scur) frame(x - 2, y - 2, 40, 38, 3, COL(255, 255, 255));
        if (g_slotT[DEALER][i] > 0) {                          /* used: puff out and fade */
            float k = 1 - g_slotT[DEALER][i] / 20.0f, sc = 1 + 0.4f * k;
            C2D_DrawRectSolid(x + 18 - 18 * sc, y + 17 - 17 * sc, 0.5f, 36 * sc, 34 * sc,
                              alpha(item_col(g_slotItem[DEALER][i]), (int)(220 * (1 - k))));
        }
    }

    /* action buttons */
    if (stealing) {
        C2D_DrawRectSolid(8, 52, 0.3f, 304, 56, COL(90, 60, 70));
        textc(160, 58, 0.5f, COL(255, 255, 255), "Pick one of Jimbo's items to steal");
        textc(160, 80, 0.45f, COL(230, 200, 200), "tap twice to confirm  -  B / tap here: cancel");
    } else {
        u32 on1 = myturn ? COL(170, 50, 45) : COL(70, 50, 50);
        u32 on2 = myturn ? COL(50, 90, 150) : COL(45, 55, 70);
        C2D_DrawRectSolid(8, 52, 0.3f, 148, 56, on1);
        C2D_DrawRectSolid(164, 52, 0.3f, 148, 56, on2);
        textc(82, 62, 0.55f, COL(255, 255, 255), "SHOOT JIMBO");
        textc(82, 84, 0.4f, COL(255, 220, 220), "(X)");
        textc(238, 62, 0.55f, COL(255, 255, 255), "SHOOT SELF");
        textc(238, 84, 0.4f, COL(220, 230, 255), "(B)  blank = extra turn");
        if (myturn) {                                          /* "your move" glow */
            int a = 70 + (int)(pulse * 150);
            frame(6, 50, 152, 60, 2, alpha(COL(255, 255, 255), a));
            frame(162, 50, 152, 60, 2, alpha(COL(255, 255, 255), a));
        }
    }

    /* description of the selected item / Jimbo's turn */
    int sel = stealing ? g->items[DEALER][g_scur] : g->items[PLAYER][g_cur];
    if (g->phase == PH_DEALER) {
        text(8, 114, 0.45f, COL(255, 230, 120), "Jimbo is thinking%.*s", (g_frame / 20) % 4, "...");
    } else if (sel) {
        text(8, 114, 0.45f, COL(255, 255, 255), "%s: %s", item_name(sel), item_desc(sel));
    } else {
        text(8, 114, 0.45f, COL(140, 140, 140), stealing ? "(empty slot)" : "Tap an item to select, tap again (or A) to use.");
    }

    /* your items */
    for (int i = 0; i < NSLOTS; i++) {
        float x = 8 + (i % 4) * 78, y = 134 + (i / 4) * 50;
        int t = g->items[PLAYER][i];
        C2D_DrawRectSolid(x, y, 0.3f, 74, 44, item_col(t));
        if (t) item_label(x + 37, y, 44, 0.42f, t);
        if (!stealing && i == g_cur) frame(x - 2, y - 2, 78, 48, 3, COL(255, 255, 255));
        if (g_slotT[PLAYER][i] > 0) {
            float k = 1 - g_slotT[PLAYER][i] / 20.0f, sc = 1 + 0.4f * k;
            C2D_DrawRectSolid(x + 37 - 37 * sc, y + 22 - 22 * sc, 0.5f, 74 * sc, 44 * sc,
                              alpha(item_col(g_slotItem[PLAYER][i]), (int)(220 * (1 - k))));
        }
    }

    if (g_flashR > 0)                                          /* ouch */
        C2D_DrawRectSolid(0, 0, 0.9f, 320, 240, alpha(COL(220, 20, 20), g_flashR * 90 / 28));
}

/* ------------------------------------------------------------- update */

static void do_player_use(Game *g, int slot)
{
    int t = g->items[PLAYER][slot];
    if (t == IT_NONE) return;
    const char *why = NULL;
    if (!game_can_use(g, PLAYER, t, &why)) {
        game_say(g, "%s", why);
        audio_play(SFX_DENY);
        return;
    }
    if (t == IT_ADRENALINE) {
        g->adrSlot = slot;
        g_scur = 0;
        for (int i = 0; i < NSLOTS; i++) {
            int st = g->items[DEALER][i];
            if (st != IT_NONE && st != IT_ADRENALINE && game_can_use(g, PLAYER, st, NULL)) {
                g_scur = i;
                break;
            }
        }
        g->phase = PH_STEAL;
        return;
    }
    if (game_use_item(g, PLAYER, slot, -1)) game_after(g);
}

static void update(Game *g, u32 kDown, touchPosition tp)
{
    g->speechAge++;
    for (int i = 0; i < 2; i++)
        if (g->hurt[i] > 0) g->hurt[i]--;
    if (g->delay > 0) {
        g->delay--;
        return;
    }
    bool touched = (kDown & KEY_TOUCH) != 0;

    switch (g->phase) {
    case PH_TITLE:
        if (kDown & (KEY_A | KEY_TOUCH)) {
            game_new(g);
            g_cur = 0;
        }
        break;
    case PH_LOAD:
        game_load(g);
        break;
    case PH_DEALER:
        game_dealer_step(g);
        game_after(g);
        break;
    case PH_GAMEOVER:
    case PH_WIN:
        if (kDown & (KEY_A | KEY_TOUCH)) {
            g->phase = PH_TITLE;
            g->delay = 0;
            game_speak(g, JL_TITLE, 100);
        }
        break;

    case PH_PLAYER: {
        int shoot = -1;
        int cur0 = g_cur;
        bool use = false;
        if (kDown & KEY_DLEFT)  g_cur = (g_cur + 7) % 8;
        if (kDown & KEY_DRIGHT) g_cur = (g_cur + 1) % 8;
        if (kDown & (KEY_DUP | KEY_DDOWN)) g_cur = (g_cur + 4) % 8;
        if (kDown & KEY_X) shoot = DEALER;
        if (kDown & KEY_B) shoot = PLAYER;
        if (kDown & KEY_A) use = true;
        if (touched) {
            if (inrect(tp.px, tp.py, 8, 52, 148, 56)) shoot = DEALER;
            else if (inrect(tp.px, tp.py, 164, 52, 148, 56)) shoot = PLAYER;
            for (int i = 0; i < NSLOTS; i++) {
                if (inrect(tp.px, tp.py, 8 + (i % 4) * 78, 134 + (i / 4) * 50, 74, 44)) {
                    if (i == g_cur) use = true;
                    else g_cur = i;
                }
            }
        }
        if (g_cur != cur0) audio_play(SFX_SELECT);
        if (shoot >= 0) {
            game_shoot(g, PLAYER, shoot);
            game_after(g);
        } else if (use) {
            do_player_use(g, g_cur);
        }
        break;
    }

    case PH_STEAL: {
        bool confirm = false;
        int scur0 = g_scur;
        if (kDown & KEY_DLEFT)  g_scur = (g_scur + 7) % 8;
        if (kDown & KEY_DRIGHT) g_scur = (g_scur + 1) % 8;
        if (kDown & KEY_A) confirm = true;
        if (kDown & KEY_B) { g->phase = PH_PLAYER; break; }
        if (touched) {
            if (inrect(tp.px, tp.py, 8, 52, 304, 56)) { g->phase = PH_PLAYER; break; }
            for (int i = 0; i < NSLOTS; i++) {
                if (inrect(tp.px, tp.py, 6 + i * 39, 6, 36, 34)) {
                    if (i == g_scur) confirm = true;
                    else g_scur = i;
                }
            }
        }
        if (g_scur != scur0) audio_play(SFX_SELECT);
        if (confirm) {
            int st = g->items[DEALER][g_scur];
            const char *why = NULL;
            if (st == IT_NONE) { game_say(g, "Nothing in that slot."); audio_play(SFX_DENY); }
            else if (st == IT_ADRENALINE) { game_say(g, "Can't steal Adrenaline."); audio_play(SFX_DENY); }
            else if (!game_can_use(g, PLAYER, st, &why)) game_say(g, "%s", why);
            else if (game_use_item(g, PLAYER, g->adrSlot, g_scur)) game_after(g);
        }
        break;
    }
    }
}

/* --------------------------------------------------------------- main */

int main(void)
{
    gfxInitDefault();
    romfsInit();
    cfguInit();
    audio_init();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    g_top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    g_bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    g_buf = C2D_TextBufNew(4096);
    g_sheet = C2D_SpriteSheetLoad("romfs:/gfx/sprites.t3x");
    if (!g_sheet) svcBreak(USERBREAK_PANIC);

    srand((unsigned)osGetTime());

    static Game game;
    memset(&game, 0, sizeof game);
    game.phase = PH_TITLE;
    game_say(&game, "Shoot Jimbo or yourself. Blank on self = extra turn.");
    game_speak(&game, JL_TITLE, 100);

    anim_reset();
    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        if (kDown & KEY_START) break;
        touchPosition tp = {0, 0};
        if (kDown & KEY_TOUCH) hidTouchRead(&tp);

        if (kDown & KEY_SELECT) audio_toggle_music();
        if (game.phase == PH_TITLE) anim_reset();
        update(&game, kDown, tp);
        for (int i = 0; i < game.nsfx; i++) audio_play(game.sfxq[i]);
        game.nsfx = 0;
        for (int i = 0; i < game.nev; i++) anim_event(&game, &game.evq[i]);
        game.nev = 0;
        anim_update();
        g_lastHp[0] = game.hp[0];
        g_lastHp[1] = game.hp[1];

        /* Jimbo's squeaky typewriter voice */
        {
            static int shownBefore = 0;
            int shown = speech_shown(&game);
            if (game.speechAge == 0) shownBefore = 0;
            for (int i = shownBefore; i < shown; i++) {
                if (i % 3 == 0 && game.speech[i] != ' ') {
                    audio_blip(1.15f + (rand() % 60) / 100.0f);
                    break;
                }
            }
            shownBefore = shown;
        }

        C2D_TextBufClear(g_buf);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        draw_top(&game);
        draw_bottom(&game);
        C3D_FrameEnd(0);
        g_frame++;
    }

    C2D_SpriteSheetFree(g_sheet);
    C2D_TextBufDelete(g_buf);
    C2D_Fini();
    C3D_Fini();
    audio_exit();
    cfguExit();
    romfsExit();
    gfxExit();
    return 0;
}
