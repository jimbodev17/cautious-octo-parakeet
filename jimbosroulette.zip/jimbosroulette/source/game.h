// Jimbo's Roulette - pure game logic (no 3DS dependencies)
#ifndef GAME_H
#define GAME_H

#include <stdbool.h>

#define NSLOTS 8   // item slots per side
#define MAXSH  8   // max shells per load
#define LOGN   4   // log lines kept
#define LOGW   80

enum { PLAYER = 0, DEALER = 1 };

typedef enum {
    IT_NONE = 0,
    IT_GLASS,       // Magnifying Glass
    IT_BEER,        // Beer
    IT_CIG,         // Cigarettes
    IT_CUFFS,       // Handcuffs
    IT_SAW,         // Hand Saw
    IT_MED,         // Expired Medicine
    IT_INVERTER,    // Inverter
    IT_PHONE,       // Burner Phone
    IT_ADRENALINE,  // Adrenaline
    IT_COUNT
} Item;

typedef enum {
    SFX_BANG, SFX_CLICK, SFX_LOAD, SFX_DEAL, SFX_RACK, SFX_GLASS, SFX_HEAL,
    SFX_BAD, SFX_CUFFS, SFX_SAW, SFX_INVERT, SFX_PHONE, SFX_ADRENALINE,
    SFX_CABLE, SFX_SELECT, SFX_DENY, SFX_ROUND, SFX_WIN, SFX_LOSE, SFX_BLIP, SFX_COUNT
} Sfx;

/* Things that happened, for the UI to animate */
typedef enum {
    EV_SHOT,      // who=shooter a=target b=live c=shell pos d=damage
    EV_EJECT,     // who a=live b=shell pos            (beer)
    EV_ITEM,      // who a=item b=slot (consumed)
    EV_STEAL,     // who a=item stolen b=slot on victim
    EV_REVEAL,    // who a=shell pos                   (magnifying glass)
    EV_FLIP,      // who a=shell pos                   (inverter)
    EV_LOAD,      // a=number of shells
    EV_ROUND,     // a=round number
    EV_CUFF,      // who=user a=victim
    EV_SAW,       // who
    EV_DAMAGE,    // who a=amount
    EV_HEAL,      // who a=amount
    EV_KO         // who a=1 if it ends the game for Jimbo
} EventType;

typedef struct { int type, who, a, b, c, d; } GameEvent;

/* Jimbo's dialogue pools (keep JL_ITEM_* in the same order as Item) */
typedef enum {
    JL_TITLE, JL_ROUND1, JL_ROUND2, JL_ROUND3, JL_LOAD, JL_ITEMS,
    JL_J_HIT_YOU, JL_J_MISS_YOU, JL_J_SELF_BLANK, JL_J_SELF_LIVE,
    JL_P_HIT_J, JL_P_MISS_J, JL_P_SELF_BLANK, JL_P_SELF_LIVE,
    JL_ITEM_NONE, JL_ITEM_GLASS, JL_ITEM_BEER, JL_ITEM_CIG, JL_ITEM_CUFFS, JL_ITEM_SAW,
    JL_ITEM_MED, JL_ITEM_INVERTER, JL_ITEM_PHONE, JL_ITEM_ADRENALINE,
    JL_PL_GLASS, JL_PL_CUFFS, JL_PL_SAW, JL_PL_STEAL,
    JL_CABLE_J, JL_CABLE_P, JL_WIN, JL_LOSE, JL_COUNT
} JimboLine;

typedef enum {
    PH_TITLE,
    PH_LOAD,      // waiting to (re)load the shotgun
    PH_PLAYER,
    PH_STEAL,     // player picking an item to steal with Adrenaline
    PH_DEALER,
    PH_GAMEOVER,
    PH_WIN
} Phase;

typedef struct Game {
    Phase phase;
    int   round, maxhp;
    int   hp[2];
    bool  sudden[2];            // round 3: cables cut, no healing, next hit kills
    int   items[2][NSLOTS];
    bool  cuffed[2];            // this side skips its next turn
    bool  sawed;
    int   turn;

    int   shells[MAXSH];        // 1 = live, 0 = blank
    int   nshells, pos;
    int   nlive0, nblank0;      // announced counts for the current load
    int   spentv[MAXSH];        // values of ejected shells, in order
    int   known[2][MAXSH + 1];  // what each side knows (-1 unknown)
    int   bel[2][2];            // each side's tracked counts [blank, live]
    bool  unsure[2];            // counts no longer trustworthy (inverter)

    int   adrSlot;              // player's adrenaline slot while stealing
    int   delay;                // frames the UI should wait before next step
    int   hurt[2];              // UI shake timers

    char  log[LOGN][LOGW];

    char  speech[112];          // what Jimbo is currently saying
    int   speechAge;            // frames since he started (UI increments)
    int   speechSerial;         // bumps on every new line
    int   lastLine[JL_COUNT];

    GameEvent evq[32];          // animation events for the UI
    int   nev;

    int   sfxq[16];             // sound events for the UI to play
    int   nsfx;
} Game;

void game_new(Game *g);
void game_next_round(Game *g);
void game_load(Game *g);
void game_after(Game *g);                       // call after every action
void game_say(Game *g, const char *fmt, ...);
void game_sfx(Game *g, int sfx);
void game_event(Game *g, int type, int who, int a, int b, int c, int d);
void game_speak(Game *g, int pool, int chancePct);
int  game_pool_size(int pool);                  // for tests
const char *game_pool_line(int pool, int i);

int  game_find_item(const Game *g, int who, int item);
int  game_cur_known(const Game *g, int who);    // -1 unknown, 0 blank, 1 live
bool game_can_use(const Game *g, int who, int item, const char **why);
bool game_can_steal(const Game *g, int who);
bool game_use_item(Game *g, int who, int slot, int stealSlot);
void game_shoot(Game *g, int who, int target);
void game_dealer_step(Game *g);                 // one dealer action

const char *item_name(int t);
const char *item_short(int t);
const char *item_desc(int t);

#endif
