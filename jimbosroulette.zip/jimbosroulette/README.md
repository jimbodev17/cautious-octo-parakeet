# Jimbo's Roulette

A from-scratch, fan-made shotgun-roulette game for the Nintendo 3DS family (works on the original 2DS/3DS).
It contains no assets or code from any other game. Jimbo, the dealer, wears the face you supplied.

## Build
1. Install devkitPro with the `3ds-dev` group (devkitARM, libctru, citro2d, citro3d, tex3ds, 3dsxtool, smdhtool).
2. `export DEVKITPRO=/opt/devkitpro DEVKITARM=/opt/devkitpro/devkitARM`
3. `make`  ->  `jimbosroulette.3dsx`
4. Copy the `.3dsx` to `/3ds/` on the SD card and launch it from the Homebrew Launcher (Luma3DS).

## Sound
Sound uses the 3DS DSP, which needs `sdmc:/3ds/dspfirm.cdc` on the SD card (dump it once with the
"DSP1" homebrew app). Without it the game runs silently and says so on the title screen.
All effects and the music loop are synthesized by `tools/make_sfx.py` (needs numpy + scipy).
The generated files are already in `romfs/sfx/`; re-run the script to tweak them.
Effects: Jimbo's voice blip, shot, click, loading, item dealing, rack, magnifier, heal, bad medicine, handcuffs, saw,
inverter, phone, adrenaline, cables cut, menu select/deny, round start, win, lose, plus a looping ambient track.

## Jimbo's dialogue
Jimbo is a chatty, chaotic goofball. He talks in a speech bubble next to his face, typed out letter by
letter with squeaky voice blips (random pitch each time). The game pauses briefly so you can read him.
He has 87 lines across 31 situations:
- greeting on the title screen, and intros for each round (he's "not nervous" in round 3)
- loading the shotgun and dealing items
- shooting you, shooting himself, getting shot, and every blank/live combination
- each item he uses, plus reactions when *you* use the magnifier, handcuffs, saw, or Adrenaline
- cables getting cut, and what he says when you win or lose

He doesn't comment on everything, so he stays fresh. To add or change lines, edit the `L_*` arrays near
the top of `source/game.c` (keep lines under ~100 characters, ASCII only).

## Animations
Nothing flashy, just enough to see what happened:
- **Shots:** screen shake, a white muzzle flash, and a red vignette when you're hit, plus a big BANG! (BOOM! when
  sawed-off) or a grey *click*. The spent shell pops out of the tracker and tumbles away.
- **Charges:** lost charges flash white/red and shrink away, healed ones flash green, with floating -1 / +2 numbers.
- **Jimbo's face:** idle bobbing, wobbling while he talks, shaking and tilting when hit, lunging when he shoots you,
  hopping when he gets a blank, a victory dance when you die. When you knock him out he spins away and pops back for
  the next round (and topples over for good if you win).
- **Items:** a card slides in showing who used what ("JIMBO STEALS: Magnifying Glass"), and the used slot puffs out.
  The magnifier ripples the revealed shell white; the inverter ripples it purple.
- **Loading:** shells drop into the tracker one by one. Round banners slide across the screen.
- **Whose turn:** a pulsing arrow by YOU / JIMBO, a glowing outline on your buttons, and "Jimbo is thinking...".

## Controls
| Action | Buttons | Touch |
|---|---|---|
| Shoot Jimbo | X | SHOOT JIMBO |
| Shoot yourself | B | SHOOT SELF |
| Select item | D-pad | tap an item |
| Use item | A | tap the selected item again |
| Adrenaline | pick one of Jimbo's items with D-pad/tap, A or tap again to confirm; B cancels | |
| Music on/off | SELECT | |
| Quit | START | |

## Rules implemented
- 3 rounds. Both sides get 2 / 4 / 4 charges. Round 1 has no items.
- Each load is 2-8 shells with at least one live and one blank; the counts are announced, the order is hidden.
  Ejected shells stay visible so you can track them. You always shoot first after a load.
- Shoot Jimbo or yourself. A blank fired at yourself gives you another turn. Live = 1 damage.
- Rounds 2/3 deal 2 / 4 items to each side per load (8 slots each).
- Items: Magnifying Glass, Beer, Cigarettes, Handcuffs, Hand Saw, Expired Medicine,
  Inverter, Burner Phone, Adrenaline.
- Round 3 "sudden death": when a side loses its last normal charge, its cables are cut. It drops to
  one charge, cannot heal, and the next hit kills.
- Dying sends you back to the title screen.

## Status
Game logic and dialogue were fuzz-tested on a PC (20,000 random games, ASan/UBSan clean; every line checked to fit the bubble). The UI was also run on a PC with a
stand-in for the 3DS graphics library and its drawing was rendered to images to check layout and animations
(sanitizers clean). The real 3DS build is still untested, since the SDK wasn't available here, and the sounds have not been
listened to or seen on hardware. Bubble text width is estimated, so a line may wrap a little differently than expected. If `make` fails, or a sound is too loud, quiet, or harsh, tell me and I'll adjust it.
